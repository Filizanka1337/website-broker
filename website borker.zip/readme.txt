if program ends that mean .txt was succeful generated or the pacage was sended 
but if program ends with error that mean you created too big file for ur internet